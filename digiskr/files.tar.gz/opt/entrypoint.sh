#!/bin/bash

# If timezone isn't set, use Etc/UTC as default 
if [[ -z "${TIMEZONE}" ]]; then 
  export TZ="Etc/UTC"
fi

# Main process
cd /opt/digiskr; python3 /opt/digiskr/fetch.py
