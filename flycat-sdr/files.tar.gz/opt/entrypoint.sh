#!/bin/bash

# If gpiomem doesn't exist, create one
if [[ ! -e "/dev/gpiomem" ]]; then
    ln -s /dev/mem /dev/gpiomem
fi

/usr/bin/openssl rehash
/usr/local/bin/kiwid -debian 10 -use_spidev 1 -bg
