#!/bin/bash

# If gpiomem doesn't exist, create one
if [[ ! -e "/dev/gpiomem" ]]; then
  ln -s /dev/mem /dev/gpiomem
fi

# Fix a potential issue of OpenSSL
/usr/bin/openssl rehash

# Main process
/usr/local/bin/kiwid -debian 10 -use_spidev 1 -bg
