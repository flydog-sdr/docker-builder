#!/bin/bash

# If gpiomem doesn't exist, create one
if [[ ! -f "/dev/gpiomem" ]]; then
  ln -s /dev/mem /dev/gpiomem
fi

# Enable I2C EEPROM
if [[ ! -f "/sys/bus/i2c/devices/1-0054/eeprom" ]]; then
  echo "24c32 0x54" > /sys/class/i2c-adapter/i2c-1/new_device
fi

# Start fan
if [[ ! -f "/sys/class/gpio/gpio12/direction" ]]; then
  echo "12" > /sys/class/gpio/export
fi
if [[ "$(cat /sys/class/gpio/gpio12/direction)" != "out" ]]; then
  echo "out" > /sys/class/gpio/gpio12/direction
fi
if [[ "$(cat /sys/class/gpio/gpio12/value)" != "1" ]]; then
  echo "1" > /sys/class/gpio/gpio12/value
fi

# Main process
/usr/local/bin/kiwid -debian 10 -use_spidev 1 -bg