#!/bin/bash

# Start fan
if [[ -f "/sys/class/gpio/gpio12" ]]; then
    if [[ ! -f "/sys/class/gpio/gpio12/direction" ]]; then
        echo "12" > /sys/class/gpio/export
    fi
    if [[ "$(cat /sys/class/gpio/gpio12/direction)" != "out" ]]; then
        echo "out" > /sys/class/gpio/gpio12/direction
    fi
    if [[ "$(cat /sys/class/gpio/gpio12/value)" != "1" ]]; then
        echo "1" > /sys/class/gpio/gpio12/value
    fi
fi
    
# Fix a potential issue of OpenSSL
/usr/bin/openssl rehash

# Main process
/usr/local/bin/kiwid -debian 10 -use_spidev 1 -bg
